/* =====================================================================
   Sistema de Informacion de Evaluacion Docente Institucional Adaptable
   Borrador de modelo fisico - Microsoft SQL Server
   Equipo: Ingenieros Malas Influencias

   Notas de diseno:
   - Convencion de nombres: PascalCase, singular, esquema dbo.
   - Claves primarias: INT IDENTITY(1,1).
   - Se evita CASCADE en la mayoria de los FK para no generar ciclos de
     borrado en cascada (SQL Server no permite mas de una ruta de
     cascada hacia la misma tabla). El borrado logico se maneja con
     columnas Activo/Completada en vez de eliminar filas.
   - La "adaptabilidad" del sistema vive en:
       InstrumentoEvaluacion -> SeccionInstrumento -> Pregunta -> OpcionRespuesta
     Esto permite crear/versionar formularios de evaluacion distintos
     (con sus propias secciones, preguntas, tipos de pregunta y escalas
     de respuesta) sin modificar el esquema de la base de datos.
   ===================================================================== */

-- CREATE DATABASE EvaluacionDocenteDB;  -- Descomentar si la BD aun no existe
-- GO
-- USE EvaluacionDocenteDB;
-- GO

/* ---------------------------------------------------------------------
   1. Estructura academica
   --------------------------------------------------------------------- */

CREATE TABLE dbo.Facultad (
    Id              INT IDENTITY(1,1)   NOT NULL,
    Nombre          NVARCHAR(150)       NOT NULL,
    Siglas          NVARCHAR(20)        NULL,
    CONSTRAINT PK_Facultad PRIMARY KEY CLUSTERED (Id)
);
GO

CREATE TABLE dbo.ProgramaEducativo (
    Id                  INT IDENTITY(1,1)   NOT NULL,
    FacultadId          INT                 NOT NULL,
    Nombre              NVARCHAR(150)       NOT NULL,
    NivelEducativo      NVARCHAR(50)        NOT NULL, -- Licenciatura, Posgrado, etc.
    CONSTRAINT PK_ProgramaEducativo PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_ProgramaEducativo_Facultad FOREIGN KEY (FacultadId)
        REFERENCES dbo.Facultad (Id)
);
GO
CREATE INDEX IX_ProgramaEducativo_FacultadId ON dbo.ProgramaEducativo (FacultadId);
GO

CREATE TABLE dbo.Materia (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    ProgramaEducativoId     INT                 NOT NULL,
    Clave                   NVARCHAR(20)        NOT NULL,
    Nombre                  NVARCHAR(150)       NOT NULL,
    Creditos                TINYINT             NOT NULL DEFAULT 0,
    CONSTRAINT PK_Materia PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Materia_Clave UNIQUE (Clave),
    CONSTRAINT FK_Materia_ProgramaEducativo FOREIGN KEY (ProgramaEducativoId)
        REFERENCES dbo.ProgramaEducativo (Id)
);
GO
CREATE INDEX IX_Materia_ProgramaEducativoId ON dbo.Materia (ProgramaEducativoId);
GO

CREATE TABLE dbo.PeriodoAcademico (
    Id              INT IDENTITY(1,1)   NOT NULL,
    Nombre          NVARCHAR(50)        NOT NULL,   -- ej. '2026-2027 Semestre 1'
    FechaInicio     DATE                NOT NULL,
    FechaFin        DATE                NOT NULL,
    Activo          BIT                 NOT NULL DEFAULT 1,
    CONSTRAINT PK_PeriodoAcademico PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT CK_PeriodoAcademico_Fechas CHECK (FechaFin > FechaInicio)
);
GO

/* ---------------------------------------------------------------------
   2. Usuarios, roles, docentes y estudiantes
   --------------------------------------------------------------------- */

CREATE TABLE dbo.Usuario (
    Id                  INT IDENTITY(1,1)   NOT NULL,
    CorreoElectronico   NVARCHAR(150)       NOT NULL,
    ContrasenaHash      NVARCHAR(256)       NOT NULL,
    Activo              BIT                 NOT NULL DEFAULT 1,
    FechaCreacion       DATETIME2           NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT PK_Usuario PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Usuario_Correo UNIQUE (CorreoElectronico)
);
GO

CREATE TABLE dbo.Rol (
    Id      INT IDENTITY(1,1)   NOT NULL,
    Nombre  NVARCHAR(50)        NOT NULL, -- Administrador, Coordinador, Docente, Estudiante
    CONSTRAINT PK_Rol PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Rol_Nombre UNIQUE (Nombre)
);
GO

CREATE TABLE dbo.UsuarioRol (
    UsuarioId   INT NOT NULL,
    RolId       INT NOT NULL,
    CONSTRAINT PK_UsuarioRol PRIMARY KEY CLUSTERED (UsuarioId, RolId),
    CONSTRAINT FK_UsuarioRol_Usuario FOREIGN KEY (UsuarioId)
        REFERENCES dbo.Usuario (Id),
    CONSTRAINT FK_UsuarioRol_Rol FOREIGN KEY (RolId)
        REFERENCES dbo.Rol (Id)
);
GO

CREATE TABLE dbo.Docente (
    Id                  INT IDENTITY(1,1)   NOT NULL,
    UsuarioId           INT                 NOT NULL,
    FacultadId          INT                 NOT NULL,
    NumeroEmpleado      NVARCHAR(20)        NOT NULL,
    Nombre              NVARCHAR(100)       NOT NULL,
    ApellidoPaterno     NVARCHAR(100)       NOT NULL,
    ApellidoMaterno     NVARCHAR(100)       NULL,
    CONSTRAINT PK_Docente PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Docente_NumeroEmpleado UNIQUE (NumeroEmpleado),
    CONSTRAINT UQ_Docente_UsuarioId UNIQUE (UsuarioId),
    CONSTRAINT FK_Docente_Usuario FOREIGN KEY (UsuarioId)
        REFERENCES dbo.Usuario (Id),
    CONSTRAINT FK_Docente_Facultad FOREIGN KEY (FacultadId)
        REFERENCES dbo.Facultad (Id)
);
GO
CREATE INDEX IX_Docente_FacultadId ON dbo.Docente (FacultadId);
GO

CREATE TABLE dbo.Estudiante (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    UsuarioId               INT                 NOT NULL,
    ProgramaEducativoId     INT                 NOT NULL,
    Matricula               NVARCHAR(20)        NOT NULL,
    Nombre                  NVARCHAR(100)       NOT NULL,
    ApellidoPaterno         NVARCHAR(100)       NOT NULL,
    ApellidoMaterno         NVARCHAR(100)       NULL,
    CONSTRAINT PK_Estudiante PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Estudiante_Matricula UNIQUE (Matricula),
    CONSTRAINT UQ_Estudiante_UsuarioId UNIQUE (UsuarioId),
    CONSTRAINT FK_Estudiante_Usuario FOREIGN KEY (UsuarioId)
        REFERENCES dbo.Usuario (Id),
    CONSTRAINT FK_Estudiante_ProgramaEducativo FOREIGN KEY (ProgramaEducativoId)
        REFERENCES dbo.ProgramaEducativo (Id)
);
GO
CREATE INDEX IX_Estudiante_ProgramaEducativoId ON dbo.Estudiante (ProgramaEducativoId);
GO

/* ---------------------------------------------------------------------
   3. Grupos e inscripciones
   --------------------------------------------------------------------- */

CREATE TABLE dbo.Grupo (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    MateriaId               INT                 NOT NULL,
    DocenteId               INT                 NOT NULL,
    PeriodoAcademicoId      INT                 NOT NULL,
    Seccion                 NVARCHAR(10)        NOT NULL,  -- ej. 'A', '01'
    CupoMaximo              SMALLINT            NOT NULL DEFAULT 0,
    CONSTRAINT PK_Grupo PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Grupo_Oferta UNIQUE (MateriaId, DocenteId, PeriodoAcademicoId, Seccion),
    CONSTRAINT FK_Grupo_Materia FOREIGN KEY (MateriaId)
        REFERENCES dbo.Materia (Id),
    CONSTRAINT FK_Grupo_Docente FOREIGN KEY (DocenteId)
        REFERENCES dbo.Docente (Id),
    CONSTRAINT FK_Grupo_PeriodoAcademico FOREIGN KEY (PeriodoAcademicoId)
        REFERENCES dbo.PeriodoAcademico (Id)
);
GO
CREATE INDEX IX_Grupo_DocenteId ON dbo.Grupo (DocenteId);
CREATE INDEX IX_Grupo_PeriodoAcademicoId ON dbo.Grupo (PeriodoAcademicoId);
GO

CREATE TABLE dbo.Inscripcion (
    Id                  INT IDENTITY(1,1)   NOT NULL,
    EstudianteId        INT                 NOT NULL,
    GrupoId              INT                 NOT NULL,
    FechaInscripcion    DATE                NOT NULL DEFAULT CAST(SYSDATETIME() AS DATE),
    CONSTRAINT PK_Inscripcion PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Inscripcion_Estudiante_Grupo UNIQUE (EstudianteId, GrupoId),
    CONSTRAINT FK_Inscripcion_Estudiante FOREIGN KEY (EstudianteId)
        REFERENCES dbo.Estudiante (Id),
    CONSTRAINT FK_Inscripcion_Grupo FOREIGN KEY (GrupoId)
        REFERENCES dbo.Grupo (Id)
);
GO
CREATE INDEX IX_Inscripcion_GrupoId ON dbo.Inscripcion (GrupoId);
GO

/* ---------------------------------------------------------------------
   4. Instrumentos de evaluacion adaptables (formularios dinamicos)
   --------------------------------------------------------------------- */

CREATE TABLE dbo.InstrumentoEvaluacion (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    CreadoPorUsuarioId      INT                 NOT NULL,
    Nombre                  NVARCHAR(150)       NOT NULL,
    TipoEvaluado            NVARCHAR(30)        NOT NULL, -- 'Docente', 'Autoevaluacion', 'Coordinador'
    Version                 SMALLINT            NOT NULL DEFAULT 1,
    Activo                  BIT                 NOT NULL DEFAULT 1,
    FechaCreacion           DATETIME2           NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT PK_InstrumentoEvaluacion PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_InstrumentoEvaluacion_Usuario FOREIGN KEY (CreadoPorUsuarioId)
        REFERENCES dbo.Usuario (Id),
    CONSTRAINT CK_InstrumentoEvaluacion_TipoEvaluado
        CHECK (TipoEvaluado IN ('Docente', 'Autoevaluacion', 'Coordinador'))
);
GO

CREATE TABLE dbo.SeccionInstrumento (
    Id              INT IDENTITY(1,1)   NOT NULL,
    InstrumentoId   INT                 NOT NULL,
    Nombre          NVARCHAR(150)       NOT NULL,   -- ej. 'Dominio del tema', 'Puntualidad'
    Orden           SMALLINT            NOT NULL DEFAULT 1,
    CONSTRAINT PK_SeccionInstrumento PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_SeccionInstrumento_Instrumento FOREIGN KEY (InstrumentoId)
        REFERENCES dbo.InstrumentoEvaluacion (Id)
);
GO
CREATE INDEX IX_SeccionInstrumento_InstrumentoId ON dbo.SeccionInstrumento (InstrumentoId);
GO

CREATE TABLE dbo.TipoPregunta (
    Id      INT IDENTITY(1,1)   NOT NULL,
    Nombre  NVARCHAR(50)        NOT NULL, -- EscalaLikert, OpcionMultiple, SiNo, TextoAbierto, Numerica
    CONSTRAINT PK_TipoPregunta PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_TipoPregunta_Nombre UNIQUE (Nombre)
);
GO

CREATE TABLE dbo.Pregunta (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    SeccionInstrumentoId    INT                 NOT NULL,
    TipoPreguntaId          INT                 NOT NULL,
    Texto                   NVARCHAR(500)       NOT NULL,
    Orden                   SMALLINT            NOT NULL DEFAULT 1,
    Obligatoria             BIT                 NOT NULL DEFAULT 1,
    PesoPonderacion         DECIMAL(5,2)        NOT NULL DEFAULT 1.00,
    CONSTRAINT PK_Pregunta PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_Pregunta_SeccionInstrumento FOREIGN KEY (SeccionInstrumentoId)
        REFERENCES dbo.SeccionInstrumento (Id),
    CONSTRAINT FK_Pregunta_TipoPregunta FOREIGN KEY (TipoPreguntaId)
        REFERENCES dbo.TipoPregunta (Id)
);
GO
CREATE INDEX IX_Pregunta_SeccionInstrumentoId ON dbo.Pregunta (SeccionInstrumentoId);
GO

CREATE TABLE dbo.OpcionRespuesta (
    Id              INT IDENTITY(1,1)   NOT NULL,
    PreguntaId      INT                 NOT NULL,
    Texto           NVARCHAR(200)       NOT NULL,  -- ej. 'Totalmente de acuerdo'
    Valor           DECIMAL(5,2)        NOT NULL,  -- valor numerico de la opcion (ej. 5, 4, 3...)
    Orden           SMALLINT            NOT NULL DEFAULT 1,
    CONSTRAINT PK_OpcionRespuesta PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_OpcionRespuesta_Pregunta FOREIGN KEY (PreguntaId)
        REFERENCES dbo.Pregunta (Id)
);
GO
CREATE INDEX IX_OpcionRespuesta_PreguntaId ON dbo.OpcionRespuesta (PreguntaId);
GO

/* ---------------------------------------------------------------------
   5. Aplicacion de evaluaciones y respuestas
   --------------------------------------------------------------------- */

CREATE TABLE dbo.PeriodoEvaluacion (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    PeriodoAcademicoId      INT                 NOT NULL,
    InstrumentoId           INT                 NOT NULL,
    Nombre                  NVARCHAR(150)       NOT NULL, -- ej. 'Evaluacion Docente 2026-2027-1'
    FechaInicio             DATETIME2           NOT NULL,
    FechaFin                DATETIME2           NOT NULL,
    Activo                  BIT                 NOT NULL DEFAULT 1,
    CONSTRAINT PK_PeriodoEvaluacion PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_PeriodoEvaluacion_PeriodoAcademico FOREIGN KEY (PeriodoAcademicoId)
        REFERENCES dbo.PeriodoAcademico (Id),
    CONSTRAINT FK_PeriodoEvaluacion_Instrumento FOREIGN KEY (InstrumentoId)
        REFERENCES dbo.InstrumentoEvaluacion (Id),
    CONSTRAINT CK_PeriodoEvaluacion_Fechas CHECK (FechaFin > FechaInicio)
);
GO
CREATE INDEX IX_PeriodoEvaluacion_PeriodoAcademicoId ON dbo.PeriodoEvaluacion (PeriodoAcademicoId);
GO

CREATE TABLE dbo.Evaluacion (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    PeriodoEvaluacionId     INT                 NOT NULL,
    EstudianteId            INT                 NOT NULL,
    GrupoId                 INT                 NOT NULL,
    FechaRespuesta          DATETIME2           NULL,
    Completada              BIT                 NOT NULL DEFAULT 0,
    Anonima                 BIT                 NOT NULL DEFAULT 1,
    CONSTRAINT PK_Evaluacion PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Evaluacion_Estudiante_Grupo_Periodo UNIQUE (EstudianteId, GrupoId, PeriodoEvaluacionId),
    CONSTRAINT FK_Evaluacion_PeriodoEvaluacion FOREIGN KEY (PeriodoEvaluacionId)
        REFERENCES dbo.PeriodoEvaluacion (Id),
    CONSTRAINT FK_Evaluacion_Estudiante FOREIGN KEY (EstudianteId)
        REFERENCES dbo.Estudiante (Id),
    CONSTRAINT FK_Evaluacion_Grupo FOREIGN KEY (GrupoId)
        REFERENCES dbo.Grupo (Id)
);
GO
CREATE INDEX IX_Evaluacion_GrupoId ON dbo.Evaluacion (GrupoId);
CREATE INDEX IX_Evaluacion_PeriodoEvaluacionId ON dbo.Evaluacion (PeriodoEvaluacionId);
GO

CREATE TABLE dbo.RespuestaEvaluacion (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    EvaluacionId            INT                 NOT NULL,
    PreguntaId              INT                 NOT NULL,
    OpcionRespuestaId       INT                 NULL,      -- si la pregunta es de opcion/escala
    RespuestaTexto          NVARCHAR(MAX)       NULL,       -- si la pregunta es abierta
    RespuestaNumerica       DECIMAL(9,2)        NULL,       -- si la pregunta es numerica
    CONSTRAINT PK_RespuestaEvaluacion PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_RespuestaEvaluacion_Evaluacion_Pregunta UNIQUE (EvaluacionId, PreguntaId),
    CONSTRAINT FK_RespuestaEvaluacion_Evaluacion FOREIGN KEY (EvaluacionId)
        REFERENCES dbo.Evaluacion (Id),
    CONSTRAINT FK_RespuestaEvaluacion_Pregunta FOREIGN KEY (PreguntaId)
        REFERENCES dbo.Pregunta (Id),
    CONSTRAINT FK_RespuestaEvaluacion_OpcionRespuesta FOREIGN KEY (OpcionRespuestaId)
        REFERENCES dbo.OpcionRespuesta (Id)
);
GO
CREATE INDEX IX_RespuestaEvaluacion_PreguntaId ON dbo.RespuestaEvaluacion (PreguntaId);
GO

/* ---------------------------------------------------------------------
   6. Resultados agregados (para dashboards / reportes)
   Nota: puede implementarse como VIEW o tabla materializada segun el
   volumen de datos; se deja como tabla para permitir precalculo por job.
   --------------------------------------------------------------------- */

CREATE TABLE dbo.ResultadoDocente (
    Id                      INT IDENTITY(1,1)   NOT NULL,
    DocenteId               INT                 NOT NULL,
    GrupoId                 INT                 NOT NULL,
    PeriodoEvaluacionId     INT                 NOT NULL,
    PromedioGeneral         DECIMAL(5,2)        NOT NULL DEFAULT 0,
    TotalRespuestas         INT                 NOT NULL DEFAULT 0,
    FechaCalculo            DATETIME2           NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT PK_ResultadoDocente PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_ResultadoDocente_Grupo_Periodo UNIQUE (GrupoId, PeriodoEvaluacionId),
    CONSTRAINT FK_ResultadoDocente_Docente FOREIGN KEY (DocenteId)
        REFERENCES dbo.Docente (Id),
    CONSTRAINT FK_ResultadoDocente_Grupo FOREIGN KEY (GrupoId)
        REFERENCES dbo.Grupo (Id),
    CONSTRAINT FK_ResultadoDocente_PeriodoEvaluacion FOREIGN KEY (PeriodoEvaluacionId)
        REFERENCES dbo.PeriodoEvaluacion (Id)
);
GO
CREATE INDEX IX_ResultadoDocente_DocenteId ON dbo.ResultadoDocente (DocenteId);
GO

/* ---------------------------------------------------------------------
   7. Datos semilla para catalogos base
   --------------------------------------------------------------------- */

INSERT INTO dbo.Rol (Nombre) VALUES
    ('Administrador'),
    ('Coordinador'),
    ('Docente'),
    ('Estudiante');
GO

INSERT INTO dbo.TipoPregunta (Nombre) VALUES
    ('EscalaLikert'),
    ('OpcionMultiple'),
    ('SiNo'),
    ('TextoAbierto'),
    ('Numerica');
GO
