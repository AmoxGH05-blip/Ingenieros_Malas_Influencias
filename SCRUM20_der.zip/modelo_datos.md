# Modelo de datos — Sistema de Información de Evaluación Docente Institucional Adaptable

**Equipo:** Ingenieros Malas Influencias
**Entregable:** Diagrama entidad-relación conceptual + borrador de modelo físico en SQL Server

## 1. Alcance del modelo

El sistema gestiona la evaluación de docentes por parte de estudiantes, usando **instrumentos de evaluación configurables** (formularios que un coordinador puede armar con sus propias secciones, preguntas y escalas de respuesta, sin tocar la base de datos). Esa es la parte "adaptable" del sistema.

El modelo cubre cinco bloques:

1. **Estructura académica** — Facultad, Programa Educativo, Materia, Periodo Académico.
2. **Usuarios y personas** — Usuario (login), Rol, Docente, Estudiante.
3. **Oferta y matrícula** — Grupo (materia + docente + periodo) e Inscripción.
4. **Instrumentos adaptables** — Instrumento de Evaluación, Sección, Tipo de Pregunta, Pregunta, Opción de Respuesta.
5. **Aplicación y resultados** — Periodo de Evaluación, Evaluación, Respuesta de Evaluación, Resultado Docente (agregado).

## 2. Diagrama entidad-relación conceptual

Ver `der_conceptual.png` (generado a partir de `der_conceptual.mmd`, editable en cualquier herramienta compatible con Mermaid).

20 entidades, con las relaciones principales:

- Un **Docente** pertenece a una **Facultad** e imparte varios **Grupo** (materia + periodo).
- Un **Estudiante** pertenece a un **Programa Educativo** y se **Inscribe** en varios **Grupo**.
- Un **Instrumento de Evaluación** se organiza en **Secciones**, cada una con sus **Preguntas**, y cada pregunta tiene un **Tipo** (Likert, opción múltiple, sí/no, texto abierto, numérica) y, si aplica, sus **Opciones de Respuesta**.
- Un **Periodo de Evaluación** liga un **Periodo Académico** con el **Instrumento** que se va a aplicar en esa ventana de tiempo.
- Una **Evaluación** es la respuesta de un estudiante a un grupo/docente dentro de un periodo de evaluación; cada una contiene varias **Respuesta de Evaluación** (una por pregunta).
- **Resultado Docente** guarda el promedio agregado por grupo y periodo, pensado para alimentar dashboards sin recalcular todo en cada consulta.

## 3. Decisiones de diseño clave

- **Adaptabilidad sin cambios de esquema:** agregar una nueva pregunta, sección, escala de respuesta o un instrumento completo nuevo es solo insertar filas en `InstrumentoEvaluacion` / `SeccionInstrumento` / `Pregunta` / `OpcionRespuesta` — no requiere alterar tablas.
- **Respuesta polimórfica controlada:** `RespuestaEvaluacion` tiene tres columnas opcionales (`OpcionRespuestaId`, `RespuestaTexto`, `RespuestaNumerica`) para soportar los distintos tipos de pregunta sin necesitar una tabla por tipo.
- **Anonimato:** `Evaluacion.Anonima` (bit) permite ocultar la identidad del estudiante en reportes, aunque el dato quede en la tabla para trazabilidad/integridad si se necesita auditar.
- **Integridad contra duplicados:** restricciones `UNIQUE` evitan que un estudiante evalúe dos veces al mismo grupo en el mismo periodo de evaluación (`Evaluacion`), o que responda dos veces la misma pregunta en una evaluación (`RespuestaEvaluacion`).
- **Versionado de instrumentos:** `InstrumentoEvaluacion.Version` permite modificar un formulario entre periodos sin perder el histórico de respuestas del instrumento anterior.
- **Separación Usuario / Docente / Estudiante:** `Usuario` concentra login y credenciales; `Docente` y `Estudiante` guardan los datos específicos de cada rol y se relacionan 1 a 1 con `Usuario`. Los permisos del sistema (Administrador, Coordinador, Docente, Estudiante) se manejan aparte en `Rol` / `UsuarioRol`, para poder dar más de un rol a la misma persona si hace falta.

## 4. Modelo físico (SQL Server)

Ver `modelo_fisico_sqlserver.sql` — script T-SQL con las 20 tablas, llaves primarias/foráneas, `UNIQUE`, `CHECK` e índices sobre las columnas de llave foránea más consultadas, más datos semilla para los catálogos `Rol` y `TipoPregunta`.

Notas técnicas:

- Llaves primarias `INT IDENTITY(1,1)`.
- `NVARCHAR` para texto (soporta acentos/ñ), `NVARCHAR(MAX)` solo para respuestas abiertas.
- `DECIMAL(5,2)` para promedios y pesos de ponderación, `DATETIME2` para timestamps.
- Sin `ON DELETE CASCADE` para evitar ciclos de borrado en cascada; los borrados se manejan lógicamente con columnas `Activo`/`Completada`.
- El script fue validado de forma automática (balance de paréntesis, orden de dependencias de llaves foráneas, nombres de constraint sin duplicados) — falta correrlo contra una instancia real de SQL Server para la validación final.

## 5. Siguientes pasos sugeridos

- Ejecutar el script en el servidor de SQL Server del equipo y validar que corra sin errores.
- Definir vistas o procedimientos almacenados para los reportes de resultados por docente/grupo/periodo.
- Revisar con el resto del equipo si se requieren entidades adicionales (ej. notificaciones, bitácora de auditoría) conforme avancen los sprints de Backend/Frontend.
